#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [[ ! -f compose.yaml || ! -d store/apps/backend || ! -f .env ]]; then
  echo 'ERROR: Place rsvx7-solace in the existing digital_store_medusa_kit root.' >&2
  exit 1
fi
if ! grep -Eq '^NEXT_PUBLIC_MEDUSA_PUBLISHABLE_KEY=pk_[A-Za-z0-9_-]+' .env; then
  echo 'ERROR: Create and set the real Medusa Publishable API key in .env first.' >&2
  exit 1
fi
if [[ -e solace-staging && ! -d solace-staging/.git ]]; then
  echo 'ERROR: solace-staging already exists and is not a Git checkout.' >&2; exit 1
fi
if [[ ! -d solace-staging/.git ]]; then
  git clone --depth 1 https://github.com/embiro/medusa-storefront-demo.git solace-staging
else
  echo '[INFO] Reusing existing Solace checkout; not pulling moving upstream commits.'
fi
printf 'Source revision: '
git -C solace-staging rev-parse HEAD
python3 rsvx7-solace/patch_solace.py --repo solace-staging --logo rsvx7-solace/assets/logo-original.jpg
# Ignore workspace state and demo assets in Docker context where possible.
cat > solace-staging/.dockerignore <<'IGNORE'
.git
.next
node_modules
*.log
.env
.env.*
.rsvx7-backups
IGNORE

echo '[OK] Solace staged. Existing Medusa DB and old storefront unchanged.'
