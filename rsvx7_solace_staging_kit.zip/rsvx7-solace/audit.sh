#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT" || exit 1
printf '\n== SYSTEM RESOURCES ==\n'
free -h
df -h .
printf '\n== DOCKER CONTAINERS ==\n'
docker compose ps || true
printf '\n== ONE-SHOT UTILIZATION ==\n'
docker stats --no-stream --format 'table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}' 2>/dev/null || true
printf '\n== SERVICE LATENCY, LOCAL ONLY ==\n'
for url in http://127.0.0.1:9000/health http://127.0.0.1:8000/ http://127.0.0.1:8001/; do
  curl -sS -L -o /dev/null --max-time 15 \
    -w '%{url_effective} : HTTP %{http_code}, connect %{time_connect}s, TTFB %{time_starttransfer}s, total %{time_total}s\n' "$url" || true
done
printf '\n== CURRENT START COMMANDS (NO SECRETS) ==\n'
if grep -nE 'medusa develop|pnpm dev|next dev|NODE_ENV: development' compose.yaml; then
 echo '[NOTICE] Development processes still exist. Do not call this production-ready.'
fi
printf '\n== BACKEND RECENT WARNINGS ==\n'
docker compose logs --tail=120 backend 2>/dev/null | grep -Ei 'warn:|error:|timeout|failed|in-memory|local event bus' | tail -30 || true
printf '\n== KNOWN PRODUCTION GAPS ==\n'
echo 'Redis event bus / workflow engine / locking / cache should be configured and tested.'
echo 'Checkout, digital rights, download privacy, backups and security updates need end-to-end verification.'
