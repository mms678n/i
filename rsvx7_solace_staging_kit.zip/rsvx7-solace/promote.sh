#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [[ "${RSVX7_TESTED_ORDERS:-}" != 'yes' ]]; then
  echo 'BLOCKED: Complete account, cart, purchase, wallet, downloads, refunds and mobile tests first.' >&2
  echo 'Only after those checks, explicitly run: RSVX7_TESTED_ORDERS=yes bash rsvx7-solace/promote.sh' >&2
  exit 1
fi
CADDY_FILE='rsvx7-branding/branding/Caddyfile'
[[ -f "$CADDY_FILE" ]] || { echo 'No existing Caddyfile; cannot promote.' >&2; exit 1; }
[[ -f 'rsvx7-branding/compose.branding.yaml' ]] || { echo 'Missing current HTTPS overlay.' >&2; exit 1; }
if ! curl -fsSL --max-time 30 http://127.0.0.1:8001/ | grep -iq 'RSVX7\|Tools for what'; then
  echo 'Staging homepage smoke test failed; not switching public traffic.' >&2; exit 1
fi
args=(-f compose.yaml -f rsvx7-branding/compose.branding.yaml -f rsvx7-solace/compose.solace.yaml)
docker compose "${args[@]}" ps solace
if ! grep -q 'reverse_proxy storefront:8000' "$CADDY_FILE"; then
  echo 'Expected old route absent; no modification applied.' >&2;exit 1
fi
cp -p "$CADDY_FILE" rsvx7-solace/Caddyfile.before-solace
python3 - <<'PY'
from pathlib import Path
p=Path('rsvx7-branding/branding/Caddyfile')
s=p.read_text()
if s.count('reverse_proxy storefront:8000') != 1:
    raise SystemExit('Unexpected proxy topology, no edit')
p.write_text(s.replace('reverse_proxy storefront:8000','reverse_proxy solace:8000'))
PY
if ! docker compose "${args[@]}" exec -T caddy caddy reload --config /etc/caddy/Caddyfile; then
  cp rsvx7-solace/Caddyfile.before-solace "$CADDY_FILE"
  docker compose "${args[@]}" exec -T caddy caddy reload --config /etc/caddy/Caddyfile || true
  echo 'ERROR: Caddy reload failed, restored previous config.' >&2
  exit 1
fi
echo '[OK] Live traffic switched to Solace. Old storefront container still present.'
echo '[ROLLBACK] bash rsvx7-solace/rollback.sh'
