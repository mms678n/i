#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
[[ -f rsvx7-solace/Caddyfile.before-solace ]] || { echo 'No saved pre-Solace Caddyfile'; exit 1; }
cp -p rsvx7-solace/Caddyfile.before-solace rsvx7-branding/branding/Caddyfile
args=(-f compose.yaml -f rsvx7-branding/compose.branding.yaml -f rsvx7-solace/compose.solace.yaml)
docker compose "${args[@]}" up -d --no-deps storefront
# Reload original routing without deleting any persistent data.
docker compose "${args[@]}" exec -T caddy caddy reload --config /etc/caddy/Caddyfile
echo '[OK] Old storefront restored.'
