#!/usr/bin/env python3
"""Careful, reviewable adaptation of the known Solace fork for an isolated RSVX7 staging site.

This never touches the existing Medusa application or its database.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import re
import shutil

HOME = r'''import Image from 'next/image'
import { getProductsList } from '@lib/data/products'
import { getRegion } from '@lib/data/regions'
import { ProductCarousel } from '@modules/products/components/product-carousel'
import LocalizedClientLink from '@modules/common/components/localized-client-link'

export const metadata = {
  title: 'Rsvx7-Store | Digital software & tools',
  description: 'Software, digital tools and licenses from Rsvx7-Store.',
}

export default async function Home({
  params,
}: {
  params: Promise<{ countryCode: string }>
}) {
  const { countryCode } = await params
  const [region, { response }] = await Promise.all([
    getRegion(countryCode),
    getProductsList({ countryCode, pageParam: 1, queryParams: { limit: 9 } }),
  ])

  return (
    <>
      <section className="rsvx7-hero" aria-labelledby="rsvx7-title">
        <div className="rsvx7-hero-noise" aria-hidden="true" />
        <div className="rsvx7-hero-content">
          <p className="rsvx7-eyebrow">CURATED DIGITAL SOFTWARE &amp; UTILITIES</p>
          <div className="rsvx7-logo-wrap">
            <Image src="/brand/rsvx7-store-logo.jpg" alt="Rsvx7-Store emblem"
              width={112} height={112} priority className="rsvx7-logo-image" />
          </div>
          <h1 id="rsvx7-title">Tools for what’s next.</h1>
          <p className="rsvx7-hero-subtitle">
            Discover software, developer tools and digital licenses.
            One account for purchases and downloads.
          </p>
          <div className="rsvx7-hero-actions">
            <LocalizedClientLink href="/shop" className="rsvx7-cta-primary">
              Explore software <span aria-hidden="true">↗</span>
            </LocalizedClientLink>
            <LocalizedClientLink href="/account" className="rsvx7-cta-secondary">
              My account
            </LocalizedClientLink>
          </div>
        </div>
        <div className="rsvx7-hero-bottom">
          <span>RSVX7 / DIGITAL STORE</span><span>SOFTWARE · TOOLS · LICENSES</span>
        </div>
      </section>
      <div className="rsvx7-intro">
        <span>01 / DISCOVER</span>
        <h2>Selected digital tools</h2>
        <p>Browse the latest software in our catalog.</p>
      </div>
      {region && response.products.length > 0 ? (
        <ProductCarousel products={response.products} regionId={region.id}
          title="Featured products" viewAll={{link:'/shop',text:'View all software'}} />
      ) : (
        <div className="rsvx7-empty">Our digital catalog is being prepared.</div>
      )}
    </>
  )
}
'''

STORE = r'''import LocalizedClientLink from '@modules/common/components/localized-client-link'
import { getProductsList } from '@lib/data/products'
import { getRegion } from '@lib/data/regions'
import { ProductTile } from '@modules/products/components/product-tile'
import { getProductPrice } from '@lib/util/get-product-price'

export default async function StoreTemplate({
  params,
  searchParams,
}: {
  params: Promise<{ countryCode: string }>
  searchParams?: Promise<{ page?: string }>
}) {
  const { countryCode } = await params
  const query = (await searchParams) ?? {}
  const page = Math.max(1, Math.min(500, Number.parseInt(query.page ?? '1', 10) || 1))
  const [region, { response, nextPage }] = await Promise.all([
    getRegion(countryCode),
    getProductsList({ countryCode, pageParam: page, queryParams: { limit: 12 } }),
  ])
  return (
    <section className="rsvx7-catalog">
      <p className="rsvx7-eyebrow">RSVX7 / ALL PRODUCTS</p>
      <h1>Digital catalog</h1>
      <p>Discover utilities, software and digital licenses.</p>
      <div className="rsvx7-products">
        {response.products.map((product) => {
          const price = getProductPrice({product}).cheapestPrice
          return (
            <ProductTile key={product.id} regionId={region?.id ?? ''}
              product={{
                id: product.id,
                created_at: product.created_at,
                title: product.title,
                handle: product.handle,
                thumbnail: product.thumbnail,
                calculatedPrice: price?.calculated_price ?? '',
                salePrice: price?.original_price ?? '',
              }} />
          )
        })}
      </div>
      {!response.products.length && <p className="rsvx7-empty">No products available yet.</p>}
      <nav aria-label="Product pages" className="rsvx7-pagination">
        {page > 1 && <LocalizedClientLink href={`/shop?page=${page-1}`}>← Previous</LocalizedClientLink>}
        <span>Page {page}</span>
        {nextPage && <LocalizedClientLink href={`/shop?page=${page+1}`}>Next →</LocalizedClientLink>}
      </nav>
    </section>
  )
}
'''

CSS = r'''/* RSVX7-SOLACE theme, appended by rsvx7-solace staging kit */
:root {color-scheme: dark;}
body {background: #050505 !important;color: #f9f9f9;}
::selection {background:#fff;color:#050505;}
.rsvx7-hero {position:relative;min-height:min(85vh,860px);background:radial-gradient(ellipse at 49% 30%, #282828 0%, #111 35%, #050505 75%);color:#fff;overflow:hidden;display:flex;align-items:center;justify-content:center;padding:100px 24px 85px;text-align:center;border-bottom:1px solid #2e2e2e;}
.rsvx7-hero-noise {position:absolute;inset:0;pointer-events:none;opacity:.26;background-image:linear-gradient(90deg,transparent 49.95%,#ffffff09 50%,transparent 50.05%), linear-gradient(transparent 49.95%,#ffffff08 50%,transparent 50.05%);background-size:80px 80px;mask-image:linear-gradient(to bottom,#000,transparent);}
.rsvx7-hero-content {position:relative;max-width:880px;display:flex;align-items:center;flex-direction:column;}
.rsvx7-eyebrow {font-size:10px;letter-spacing:.25em;font-weight:700;color:#a8a8a8;text-transform:uppercase;}
.rsvx7-logo-wrap {margin:32px 0 34px;width:114px;height:114px;box-shadow:0 0 110px #ffffff24;border-radius:26px;overflow:hidden;border:1px solid #777;}
.rsvx7-logo-image {width:100%;height:100%;object-fit:cover;filter:grayscale(1);}
.rsvx7-hero h1 {font-size:clamp(48px,8vw,106px);line-height:1.02;letter-spacing:-.065em;font-weight:650;max-width:820px;}
.rsvx7-hero-subtitle {font-size:clamp(15px,2vw,20px);color:#c2c2c2;line-height:1.8;max-width:560px;margin-top:26px;}
.rsvx7-hero-actions {display:flex;gap:12px;flex-wrap:wrap;justify-content:center;margin-top:36px;}
.rsvx7-cta-primary,.rsvx7-cta-secondary {font-size:13px;font-weight:650;display:inline-flex;align-items:center;justify-content:center;gap:20px;min-width:175px;padding:16px 20px;border-radius:4px;transition:background .2s,color .2s,border-color .2s;}
.rsvx7-cta-primary {background:#f6f6f6;color:#0b0b0b;}
.rsvx7-cta-primary:hover {background:#bcbcbc;}
.rsvx7-cta-secondary {border:1px solid #555;color:#fff;}
.rsvx7-cta-secondary:hover {border-color:#fff;}
.rsvx7-hero-bottom {position:absolute;bottom:26px;left:5%;right:5%;display:flex;justify-content:space-between;gap:12px;color:#888;font-size:9px;letter-spacing:.18em;}
.rsvx7-intro {max-width:1300px;margin:0 auto;padding:75px 28px 30px;}
.rsvx7-intro span {font-size:10px;letter-spacing:.16em;color:#aaa;}
.rsvx7-intro h2 {font-size:clamp(32px,5vw,52px);letter-spacing:-.04em;font-weight:600;margin-top:12px;}
.rsvx7-intro p {color:#aaa;margin-top:12px;}
.rsvx7-empty {padding:64px 24px;max-width:1200px;margin:auto;color:#aaa;text-align:center;}
.rsvx7-catalog {max-width:1440px;margin:0 auto;padding:80px 30px;min-height:60vh;}
.rsvx7-catalog h1 {font-size:clamp(44px,6vw,76px);letter-spacing:-.055em;font-weight:650;margin:16px 0;}
.rsvx7-catalog >p:not(.rsvx7-eyebrow) {color:#aaa;}
.rsvx7-products {display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:22px;margin-top:45px;}
.rsvx7-pagination {display:flex;gap:18px;align-items:center;justify-content:center;margin:50px 0 0;font-size:13px;}
.rsvx7-pagination a {border:1px solid #555;padding:10px 16px;border-radius:3px;}
.rsvx7-brand-header {display:flex;align-items:center;gap:10px;font-weight:720;font-size:14px;color:#fff;letter-spacing:.08em;white-space:nowrap;}
.rsvx7-brand-header img {width:34px;height:34px;border-radius:8px;object-fit:cover;filter:grayscale(1);}
@media(max-width:760px){.rsvx7-products{grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.rsvx7-hero-bottom{font-size:8px}.rsvx7-hero{min-height:690px;padding-top:80px}}
@media(max-width:460px){.rsvx7-products{grid-template-columns:1fr}.rsvx7-catalog{padding:50px 20px}}
@media(prefers-reduced-motion:reduce){.rsvx7-cta-primary,.rsvx7-cta-secondary{transition:none}}
/* END RSVX7-SOLACE theme */
'''

NEXT_CONFIG = r'''const checkEnvVariables = require('./check-env-variables')
checkEnvVariables()
const remotePatterns = []
const apiUrl = process.env.NEXT_PUBLIC_MEDUSA_BACKEND_URL
if (apiUrl) {
  try {
    const parsed = new URL(apiUrl)
    remotePatterns.push({ protocol: parsed.protocol.replace(':', ''), hostname: parsed.hostname })
  } catch (error) { throw new Error('Invalid NEXT_PUBLIC_MEDUSA_BACKEND_URL') }
}
if (process.env.NEXT_PUBLIC_SPACE_DOMAIN) {
  remotePatterns.push({protocol:'https', hostname:process.env.NEXT_PUBLIC_SPACE_DOMAIN})
}
if (process.env.NEXT_PUBLIC_CDN_SPACE_DOMAIN) {
  remotePatterns.push({protocol:'https', hostname:process.env.NEXT_PUBLIC_CDN_SPACE_DOMAIN})
}
module.exports = {
  reactStrictMode: true,
  poweredByHeader: false,
  images: { remotePatterns },
}
'''

SEARCH = r'''import { sdk } from '@lib/config'
import { safeDecodeURIComponent } from '@lib/util/safe-decode-uri'
import { SearchedProducts } from 'types/global'
export const BACKEND_URL = process.env.NEXT_PUBLIC_MEDUSA_BACKEND_URL
export const PUBLISHABLE_API_KEY = process.env.NEXT_PUBLIC_MEDUSA_PUBLISHABLE_KEY
export const PRODUCT_LIMIT = 12

type SearchParams = {
  currency_code: string
  page?: number
  order?: string
  category_id?: string
  collection?: string[]
  type?: string[]
  material?: string[]
  price?: string[]
  query?: string
}

// Uses standard Medusa /store/products; the original Solace custom /store/search
// endpoint is NOT available in a stock Medusa backend.
export async function search({
  currency_code, page = 1, category_id, collection, query,
}: SearchParams): Promise<SearchedProducts> {
  const regions = await sdk.store.region.list()
  const region = regions.regions.find(r => r.currency_code === currency_code)
  const offset = Math.max(0, (page - 1) * PRODUCT_LIMIT)
  const params: any = {
    limit: PRODUCT_LIMIT,
    offset,
    fields: '*variants.calculated_price,*variants',
    ...(region ? {region_id:region.id} : {}),
    ...(query ? {q:safeDecodeURIComponent(query)} : {}),
    ...(category_id ? {category_id:[category_id]} : {}),
    ...(collection?.length ? {collection_id:collection} : {}),
  }
  const {products,count} = await sdk.store.product.list(params)
  return {
    count,
    results: products.map((p) => {
      const variant = p.variants?.find((v:any) => v.calculated_price)
      const amount = (variant as any)?.calculated_price?.calculated_amount ?? 0
      const original = (variant as any)?.calculated_price?.original_amount ?? amount
      return {
        id:p.id,
        title:p.title,
        handle:p.handle,
        thumbnail:p.thumbnail ?? '',
        calculated_price: String(amount),
        sale_price: String(amount),
        regular_price: String(original),
        created_at:p.created_at,
        updated_at:p.updated_at,
      }
    }),
  }
}
'''


def anchored_replace(path: Path, old: str, new: str, label: str) -> None:
    text = path.read_text()
    if new in text:
        return
    if old not in text:
        raise RuntimeError(f'{label}: expected anchor missing in {path}')
    path.write_text(text.replace(old, new))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', required=True)
    ap.add_argument('--logo', required=True)
    args = ap.parse_args()
    root = Path(args.repo).resolve()
    logo = Path(args.logo).resolve()
    if not (root / 'package.json').exists() or not logo.is_file():
        raise SystemExit('Bad repo path or logo not found')
    pkg = (root / 'package.json').read_text()
    if 'solace-medusa-starter' not in pkg:
        raise SystemExit('Not recognized as the Solace starter fork')
    marker = root / '.rsvx7-backups' / 'PATCHED'
    if marker.exists():
        print('[OK] Already patched, skipping edits')
        return
    target = root / '.rsvx7-backups'
    if target.exists():
        raise SystemExit('Partial backup directory exists. Check before re-running.')
    files = [
        'src/app/[countryCode]/(main)/page.tsx',
        'src/modules/store/templates/index.tsx',
        'src/modules/layout/templates/nav/nav-content.tsx',
        'src/modules/layout/templates/footer/index.tsx',
        'src/app/layout.tsx',
        'src/styles/globals.css',
        'src/lib/data/fetch.ts',
        'src/lib/data/products.ts',
        'src/modules/search/actions.ts',
        'next.config.js',
    ]
    for rel in files:
        if not (root / rel).is_file():
            raise SystemExit('Missing Solace expected file: ' + rel)
    # Check every version-sensitive anchor before touching a single source file.
    checks = {
        'src/modules/layout/templates/nav/nav-content.tsx': [
            "import { SearchIcon, SolaceLogo } from '@modules/common/icons'",
            '<SolaceLogo className="h-6 medium:h-7" />',
        ],
        'src/modules/layout/templates/footer/index.tsx': [
            'SolaceLogo,', '<SolaceLogo />', 'Solace. All rights reserved.',
        ],
        'src/app/layout.tsx': [
            'defaultTheme="system"\n          enableSystem',
            'metadataBase: new URL(getBaseURL()),',
        ],
        'src/lib/data/fetch.ts': [') => {\n  const response = await fetch('],
        'src/lib/data/products.ts': [
            'export const getProductsList =',
            '    .then(({ products }) => {',
        ],
    }
    for rel, patterns in checks.items():
        data = (root / rel).read_text()
        for pattern in patterns:
            if pattern not in data:
                raise SystemExit(f'Incompatible Solace fork: expected anchor missing: {rel}: {pattern[:50]}')
    for rel in files:
        dest = target / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / rel, dest)
    shutil.copy2(logo, root / 'public/brand/rsvx7-store-logo.jpg' if (root / 'public/brand').exists() else create_brand_dir(root))
    (root / files[0]).write_text(HOME)
    (root / files[1]).write_text(STORE)
    (root / 'src/modules/search/actions.ts').write_text(SEARCH)
    (root / 'next.config.js').write_text(NEXT_CONFIG)
    nav = root / 'src/modules/layout/templates/nav/nav-content.tsx'
    anchored_replace(nav, "import { SearchIcon, SolaceLogo } from '@modules/common/icons'", "import { SearchIcon } from '@modules/common/icons'\nimport Image from 'next/image'", 'nav import')
    anchored_replace(nav, '<SolaceLogo className="h-6 medium:h-7" />', '<span className="rsvx7-brand-header"><Image src="/brand/rsvx7-store-logo.jpg" width={34} height={34} alt="Rsvx7-Store" /> Rsvx7-Store</span>', 'nav brand')
    footer = root / 'src/modules/layout/templates/footer/index.tsx'
    anchored_replace(footer, 'SolaceLogo,', '', 'footer logo import')
    anchored_replace(footer, '<SolaceLogo />', '<span className="rsvx7-brand-header"><img src="/brand/rsvx7-store-logo.jpg" width={34} height={34} alt="Rsvx7-Store" /> Rsvx7-Store</span>', 'footer brand')
    anchored_replace(footer, 'Solace. All rights reserved.', 'Rsvx7-Store. All rights reserved.', 'footer copyright')
    layout = root / 'src/app/layout.tsx'
    anchored_replace(layout, 'defaultTheme="system"\n          enableSystem', 'defaultTheme="dark"\n          enableSystem={false}', 'dark theme')
    anchored_replace(layout, 'metadataBase: new URL(getBaseURL()),', 'metadataBase: new URL(getBaseURL()),\n  title: "Rsvx7-Store",\n  description: "Digital software, tools and license management.",\n  icons: {icon: "/brand/rsvx7-store-logo.jpg"},', 'metadata')
    css = root / 'src/styles/globals.css'
    css.write_text(css.read_text().rstrip() + '\n\n' + CSS)
    fetch = root / 'src/lib/data/fetch.ts'
    text = fetch.read_text()
    anchor = ') => {\n  const response = await fetch('
    fallback = """) => {
  // Solace normally requires Strapi. A missing CMS must not blank the homepage.
  if (!process.env.NEXT_PUBLIC_STRAPI_URL) {
    const payload = endpoint.startsWith('/api/homepage')
      ? {data:{HeroBanner:null,MidBanner:null}}
      : {data:[]}
    return new Response(JSON.stringify(payload), {
      status:200,
      headers:{'content-type':'application/json'},
    })
  }
  const response = await fetch("""
    if anchor not in text:
        raise RuntimeError('Expected Strapi fetch anchor missing')
    fetch.write_text(text.replace(anchor, fallback, 1))
    products = root / 'src/lib/data/products.ts'
    text = products.read_text()
    start = text.find('    .then(({ products }) => {', text.index('export const getProductsList ='))
    end = text.find('    })\n}', start)
    if start < 0 or end < 0:
        raise RuntimeError('Could not find product inventory filter safely')
    end += len('    })')
    new_then = '''    .then(({ products, count }) => ({
      response: { products, count },
      nextPage: count > offset + limit ? pageParam + 1 : null,
      queryParams,
    }))'''
    products.write_text(text[:start]+new_then+text[end:])
    marker.write_text('RSVX7 Solace staging patch applied\n')
    print('[OK] Solace homepage, catalog, branding, safer default CMS, core search, product count patched')
    print('[OK] Previous files stored under .rsvx7-backups (inside new Solace clone only).')


def create_brand_dir(root: Path) -> Path:
    path = root / 'public/brand'
    path.mkdir(parents=True, exist_ok=True)
    return path / 'rsvx7-store-logo.jpg'

if __name__ == '__main__':
    main()
