#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
[[ -d solace-staging ]] || { echo 'Run bash rsvx7-solace/prepare.sh first' >&2; exit 1; }
command -v docker >/dev/null
if ! docker compose -f compose.yaml -f rsvx7-solace/compose.solace.yaml config --quiet; then
  echo 'ERROR: Bad compose config or missing publishable key.' >&2; exit 1
fi
printf '===== CURRENT RESOURCE USAGE =====\n'
free -h
df -h .
echo '[INFO] Build runs beside the existing site, no containers/volumes removed.'
DOCKER_BUILDKIT=1 docker compose -f compose.yaml -f rsvx7-solace/compose.solace.yaml build --progress=plain solace
# --no-deps means running backend is not replaced.
docker compose -f compose.yaml -f rsvx7-solace/compose.solace.yaml up -d --no-deps solace
bash rsvx7-solace/verify-stage.sh
