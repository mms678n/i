# RSVX7-STORE · Solace pilot + technical audit

## الحالة
هذه **حزمة تجهيز/اختبار** وليست ادعاء نشر أو إصلاح شامل. لا تعدّل قاعدة Medusa الحالية، وتحافظ على خدمات المتجر القديمة. مصدر Solace الأصلي `rigby-sh/solace-medusa-starter` لم يكن متاحًا عبر GitHub في فحصنا، ولذلك تستعمل الحزمة نسخة fork عامة MIT: `embiro/medusa-storefront-demo`. مصدر النسخة سيتغير مستقبلًا إذا تحرك الفرع؛ اطبع `git rev-parse HEAD` واحتفظ به للرجوع. افحص مصدر الطرف الثالث قبل تشغيله علنًا.

**تنبيه ترخيص:** صور Solace التجريبية لا تملك ترخيصًا للاستخدام التجاري؛ يجب استبدالها وعدم عرضها للعملاء. شعار RSVX7 المرفق من المستخدم، والصورة الأصلية لا يتم تعديلها؛ العرض فقط بفلتر CSS رمادي.

## المتطلبات
- المشروع مثبت في `/root/s/digital_store_medusa_kit`، Medusa يعمل محليًا على 9000 وCaddy (إن كان موجودًا) يخدم الدومين الحالي.
- أنشئ `NEXT_PUBLIC_MEDUSA_PUBLISHABLE_KEY=pk_...` الصحيح في ملف `.env` واربطه بقناة المبيعات.
- إعداد منطقة بيع فعلية مع عملة وبلدان ومنتجات ذات أسعار في لوحة Medusa.
- جهاز VPS متاح عليه Git وDocker Compose وPython3، ومساحة إضافية. 4GB RAM قد لا تكفي لبناء Solace إلى جانب باقي الخدمات؛ راقب الذاكرة أثناء البناء ولا تحذف الـ volumes.
- إعداد `https://api.rsvx7-store.com` وتأكد من عمل CORS وHTTPS قبل البناء. لا تنشر واجهة Medusa التطويرية بدون حماية.

## التشغيل (اختبار منفصل)
ارفع ZIP إلى **مجلد المشروع الأساسي**؛ لا تضعه داخل مجلد `q` أو `l`:

```bash
cd /root/s/digital_store_medusa_kit
unzip -o rsvx7_solace_staging_kit.zip -d .
chmod +x rsvx7-solace/*.sh
bash rsvx7-solace/audit.sh
bash rsvx7-solace/prepare.sh
bash rsvx7-solace/build-stage.sh
```

هذا ينزّل النسخة العامة من Solace إلى `./solace-staging` ويطبّق هوية Rsvx7-Store ويجهّز **Next.js production build** على منفذ اختبار داخلي `127.0.0.1:8001`. لا يغيّر الدومين أو مسار المبيعات الحالي.

## المعاينة من الكمبيوتر بأمان

```bash
ssh -L 8001:127.0.0.1:8001 root@2.29.7.26
```
ثم افتح على الكمبيوتر `http://localhost:8001` (البناء سيعمل على إصدار Next.js 15.5.22 داخل الحاوية إن نجح تثبيت التبعيات).

## فحص المشاكل

```bash
cd /root/s/digital_store_medusa_kit
bash rsvx7-solace/verify-stage.sh
bash rsvx7-solace/audit.sh
docker compose -f compose.yaml -f rsvx7-solace/compose.solace.yaml logs --tail=120 solace
```

أخطاء `npm run build` أو `TS` أو `500` تعني أن نسخة Solace غير جاهزة ولا يجوز تحويل الدومين لها. كل هذا يحصل مع بقاء المتجر الأصلي دون تغيير.

## تغييرات محددة
- واجهة الصفحة الرئيسية والكتالوج من نمط Solace مع هوية RSVX7 داكنة، وشعار المستخدم.
- عدم تعليق الصفحة الرئيسية عند غياب Strapi (يعيد استجابة افتراضية حيث يمكن، وليس بديل CMS متكامل).
- إزالة فلتر Solace الذي يخفي المنتجات الرقمية عند عدم وجود مخزون مادي، وتصحيح نتيجة العد/الترقيم على أساس `count`.
- استبدال البحث المعتمد على `/store/search` المخصص ببحث Medusa الاعتيادي، في حدوده الأساسية. **الفلاتر المتقدمة** التابعة لـ Solace ما زالت تحتاج تكاملًا.
- ترقية Next.js داخل صورة البناء إلى إصدار أمنّي مُصحّح مبدئيًا مع React؛ يجب اختبار التوافق على السيرفر.
- تشغيل `next build`/`next start` للواجهة الجديدة بدل `next dev`، دون المساس بنمط تشغيل Medusa الأصلي.

## ما لا تدعي الحزمة إصلاحه
- **محفظة Medusa Store Credit** وخطوات الشحن والدفع الخاصة بها: لا توجد اختبارات تكامل فعلية.
- **تنزيل الملفات/التراخيص**: صفحات Solace لا تطابق مكتبة التنزيل الأصلية تلقائيًا؛ تحتاج ترحيل واجهة Entitlements مع التحقق من صلاحيات المستخدم. النسخة الأصلية تبقى مفعّلة حتى يكتمل ذلك.
- معالجة المرتجعات والفواتير ورسائل البريد، وأمان الشراء المتزامن؛ يلزم اختبار End-to-End.
- أداء/سلامة Backend الإنتاجية: لا تزال نسخة الخادم الحالية تعمل `medusa develop` وLocal Event Bus وIn-memory Locking. تحويلها إلى Production مع Redis event bus/locking/workflow/cache خطوة **منفصلة** تحتاج مراجعة وحدات الإضافات ونسخة احتياطية قابلة للاستعادة.
- بناء/اختبار Docker الفعلي لم يجرِ في بيئة إنشاء هذه الحزمة (لا Docker ولا Internet access هنا).

## التحويل والعودة (عند إكمال جميع الاختبارات فقط)
بعد التحقق اليدوي من حسابين مختلفين ومشتريات ومدفوعات تجريبية وروابط تنزيل آمنة ومفاتيح تراخيص ومستوى الأداء والصور وResponsive، شغّل:

```bash
RSVX7_TESTED_ORDERS=yes bash rsvx7-solace/promote.sh
```
سيغيّر Caddy فقط من `storefront` إلى `solace`. إذا حصل خطأ، نفّذ:

```bash
bash rsvx7-solace/rollback.sh
```

لا تستخدم خيار التحويل ما لم تنجح كل اختبارات المحفظة والتنزيلات حتى لا يخسر العملاء الوصول للمنتجات المشتراة.

## مراجع عامة
- Solace fork MIT: https://github.com/embiro/medusa-storefront-demo
- Medusa self-host: https://docs.medusajs.com/learn/deployment/general
- Next May 2026 security: https://vercel.com/changelog/next-js-may-2026-security-release
