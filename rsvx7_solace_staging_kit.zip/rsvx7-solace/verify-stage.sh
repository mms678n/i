#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT" || exit 1
args=(-f compose.yaml -f rsvx7-solace/compose.solace.yaml)
echo '===== CONTAINER STATUS ====='
docker compose "${args[@]}" ps solace backend postgres redis
echo '===== API HEALTH ====='
curl -k -sS -o /dev/null -w 'Medusa local: %{http_code} (%{time_total}s)\n' --max-time 12 http://127.0.0.1:9000/health || true
echo '===== STAGING PAGE ====='
curl -sS -o /dev/null -w 'Solace stage: %{http_code} (%{time_total}s)\n' --max-time 25 http://127.0.0.1:8001/ || true
echo '===== RECENT ERRORS ====='
docker compose "${args[@]}" logs --tail=90 solace | tail -90
echo '===== END ====='
echo 'For secure desktop testing: ssh -L 8001:127.0.0.1:8001 root@2.29.7.26'
echo 'Then visit: http://localhost:8001'
